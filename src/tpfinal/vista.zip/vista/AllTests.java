package tpfinal.vista;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({
    LoginTest.class,
    RegisterTest.class,
    PanelClienteTest.class,
    PanelAdministradorTest.class
})
public class AllTests {
    // Esta clase debe permanecer vacía.
    // Funciona como un contenedor para la anotación @SuiteClasses.
}